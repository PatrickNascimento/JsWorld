function initvariables(){

var myToken = localStorage.getItem("keytoken");
param = window.location.href;
var io = param.indexOf("ref=");
if (io != -1) {
	var Token = param.substr(io + 4);
	console.log(Token);
	let key = "keytoken";
	localStorage.setItem(key, Token);
	console.log("Token armazenado");
	PopulateFields();
} else {
	if (myToken != null) {
		param = window.location.href;
		var io = param.indexOf("utm_source=");
		if (io != -1) {
			console.log("Logado");
			document.getElementById("containerlogado").style.visibility = "visible";
		} else {
			PopulateFields();
		}
	} else {
		console.log("não logado");
		document.getElementById("container").style.visibility = "visible";
	}
}
}

function socket(){
	var Mytime = setInterval(myTimer, 4000);

	function myTimer() {
		_param = window.location.href;
		console.log(_param);
		var _io = _param.indexOf("utm_source=");
		if (_io != -1) {
			document.getElementById("containerlogado").style.visibility = "visible";
			console.log("autenticado");
			clearInterval(Mytime);
		}
	}
}

const request = new XMLHttpRequest();
request.open('GET', 'https://back.bitcointoyou.com:443/api/v1/get-afilio-stores');
request.onload = function () {
	let result = JSON.parse(this.responseText);
	var url = "https://www.polishop.com.br/";
	for (var [key, value] of Object.entries(result)) {
		urlOne = url.split("/");
		urlTwo = result[key].url.split("/");
		if (urlOne[2] == urlTwo[2]) {
			$("#percentNumber").html(result[key].saleprice + '%');
			console.log(result[key].saleprice + '%');
			initvariables();
			socket();
		}
	}
};
request.send();