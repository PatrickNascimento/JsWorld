chrome.tabs.query({
	active: true,
	lastFocusedWindow: true
}, tabs => {
	var afiliados = [];
	const request = new XMLHttpRequest();
	request.open('GET', 'https://back.bitcointoyou.com:443/api/v1/get-afilio-stores');
	request.onload = function () {		
			var result = JSON.parse(this.responseText);
			afiliados = result;
			console.log("Afiliados", afiliados);
			let url = tabs[0].url;
			var resultsearch = 0;
			var urlx = url.split('?')[0]
			Object.keys(afiliados).forEach(function (prop) {

				urlOne = urlx.split("/");
                urlTwo = afiliados[prop].url.split("/");    

                console.log("1 ->",urlOne[2]);
                console.log("2 ->",urlTwo[2]);

            if (urlOne[2] == urlTwo[2]) {
					resultsearch = 1;
					$("#percentNumber").html(afiliados[prop].saleprice + '%');
				}
			});
			console.log(resultsearch);
			if (resultsearch == 1) {
				var io = url.indexOf("utm_source=");
				if (io != -1) {
					console.log("Logado");
					$("#Primary").hide();
					$("#Third").hide();
					$("#Secundary").show();
				} else {
					$("#Third").hide();
					$("#Primary").show();
				}
			} else {
				$("#Primary").hide();
				$("#Third").show();				
			}
		
	};
	request.send();
});