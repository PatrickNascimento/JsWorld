function getParameter(theParameter) {
            var params = window.location.search.substr(1).split('&');

            for (var i = 0; i < params.length; i++) {
                var p = params[i].split('=');
                if (p[0] == theParameter) {
                    return decodeURIComponent(p[1]);
                }
            }
            return false;
            }
            var token = getParameter('ref');    


function PopulateFields() {
	var afiliados = [];
	var id = "";
	var urlstore= "";
	const request = new XMLHttpRequest();
	request.open('GET', 'https://back.bitcointoyou.com:443/api/v1/get-afilio-stores');
	request.onreadystatechange = function () {
		if (this.readyState == 4 && this.status == 200) {
			var result = JSON.parse(this.responseText);
			afiliados = result;			
			let url = window.location.href;
			var resultsearch = 0;
			var urlx = url.split('?')[0];
			Object.keys(afiliados).forEach(function (prop) {
				if (afiliados[prop].url == urlx) {
					resultsearch = 1;	
					id = afiliados[prop].id;
					urlstore = afiliados[prop].url;
				}
			});			
			if (resultsearch == 1) {
				console.log(id);
				console.log(urlstore);
				console.log("Populated");
				var io = url.indexOf("ref=");
				if (io != -1) {
				console.log("URL-OK");
				$.ajax({
					url: "https://back.bitcointoyou.com:443/api/v1/get-afilio-deeplink?id=" + id + "&storeUrl= " + urlstore,
					dataType: "html",
					method: "GET"
				}).done(function (retorno) {
					var endURL = retorno +'&aff_xtra='+ token;
					console.log(endURL);
					window.location.href = retorno;
				});
				
			}
		}
	}
};
	request.send();
}

