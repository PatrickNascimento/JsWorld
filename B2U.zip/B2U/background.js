var afiliados = [];
const request = new XMLHttpRequest();
request.open('GET', 'https://back.bitcointoyou.com:443/api/v1/get-afilio-stores');
request.onload = function () {
    var result = JSON.parse(this.responseText);
    afiliados = result;
    console.log("Afiliados", afiliados);
};
request.send();
chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
    chrome.runtime.sendMessage({
        "message": "ReqBack"
    });
});
chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
    if (request.message === "BackSend") {
        console.log("backResquest");
    }
});
var nav = new NavigationCollector();
chrome.tabs.onUpdated.addListener(function () {
    chrome.tabs.query({
        active: true,
        currentWindow: true
    }, ([currentTab]) => {
        var _param = currentTab.url;
        console.log("Mudei");
        var _io = _param.indexOf("ref=");
        if (_io != -1) {
            console.log("rodei1");
            chrome.tabs.executeScript(null, {
                file: 'inject.js'
            });
            console.log("Rodou script REF");
        }
        var _io2 = _param.indexOf("utm_source=");
        if (_io2 != -1) {
            console.log("rodei2");
            chrome.tabs.executeScript(null, {
                file: 'inject.js'
            });
            console.log("Rodou script UTM");
        }
    });
});
/***********************************************************************************
 * Percorre as abas e valida se faz parte da lista de afiliados IconTrue/IconFalse *
/***********************************************************************************/
chrome.tabs.onActivated.addListener(function (tabId, changeInfo, tab) {
    //Valida a troca das abas
    chrome.tabs.query({
        active: true,
        currentWindow: true
    }, ([currentTab]) => {
        var _param = currentTab.url;
        var resultsearch = 0;
        var urlx = _param.split('?')[0]
        Object.keys(afiliados).forEach(function (prop) {

                urlOne = urlx.split("/");
                urlTwo = afiliados[prop].url.split("/");                             

            if (urlOne[2] == urlTwo[2]) {
                resultsearch = 1;
            }
        });
        console.log(resultsearch);
        if (resultsearch == 1) {
            chrome.browserAction.setIcon({
                path: "icontrue.png"
            });
            console.log("icontrue");
        } else {
            chrome.browserAction.setIcon({
                path: "iconfalse.png"
            });
            console.log("iconfalse");
        }
    });
});
var count = 0
chrome.webNavigation.onBeforeNavigate.addListener(function (data) {
    //var Mytime = setInterval(myTimer, 5000);    
    const request = new XMLHttpRequest()
    request.open('GET', 'https://back.bitcointoyou.com:443/api/v1/get-afilio-stores')
    request.onload = function () {
        let result = JSON.parse(this.responseText);
        afiliados = data;
        if (data.frameId == 0) {
            count += 1;
            for (var [key, value] of Object.entries(result)) {
                urlOne = data.url.split("/");
                urlTwo = result[key].url.split("/");             
                if (urlOne[2] == urlTwo[2]) {
                    chrome.browserAction.setIcon({
                        path: "icontrue.png"
                    });
                    chrome.browserAction.setBadgeText({
                        text: "" + count + ""
                    });
                    chrome.tabs.executeScript(null, {
                        file: 'inject.js'
                    });
                } else 
                console.log("Nothing");
            }
        }
    }
    request.send()
});
chrome.runtime.onStartup.addListener(function () {
    nav.resetDataStorage();
});