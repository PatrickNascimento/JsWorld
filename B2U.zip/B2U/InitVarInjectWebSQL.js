function initvariables() {	
	param = window.location.href;
	var io = param.indexOf("ref=");
	var cont = 0;
	if (io != -1) {		
		//var Token = param.substr(io + 4);
		console.log("ref entrou");		
		PopulateFields();		
	} else {
		param = window.location.href;
		var io = param.indexOf("utm_source=");
		if (io != -1) {
			console.log("Logado");
			document.getElementById("containerlogado").style.visibility = "visible";
		} else {
			document.getElementById("container").style.visibility = "visible";
		}
	}
}

var request = new XMLHttpRequest();
request.open('GET', 'https://back.bitcointoyou.com:443/api/v1/get-afilio-stores');
request.onload = function () {
	let result = JSON.parse(this.responseText);
	var url = window.location.href;
	for (var [key, value] of Object.entries(result)) {
		urlOne = url.split("/");
		urlTwo = result[key].url.split("/");
		if (urlOne[2] == urlTwo[2]) {
			$("#percentNumber").html(result[key].saleprice + '%');
			console.log(result[key].saleprice + '%');
			initvariables();
			//socket();
		}
	}
};
request.send();