document.getElementById("SendBtn").addEventListener("click", function() {
  
  //loginToken();
  alert("aqui");
});